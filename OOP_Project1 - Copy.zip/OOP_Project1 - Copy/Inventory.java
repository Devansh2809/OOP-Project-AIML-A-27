import java.util.ArrayList;
import java.util.List;

public class Inventory {
    private List<Product> products = new ArrayList<>();
    private final int lowStockThreshold = 5; // Notify when stock falls below this value

    // Add product to the inventory
    public void addProduct(Product product) {
        products.add(product);
    }

    // Display all products
    public void displayProducts() {
        for (Product product : products) {
            System.out.println(product);
        }
    }

    // Order a product (with concurrency handling and low stock notification)
    public synchronized void orderProduct(int productId, int quantity, Customer customer) {
        for (Product product : products) {
            if (product.getId() == productId) {
                if (product.getQuantity() >= quantity) {
                    product.setQuantity(product.getQuantity() - quantity);
                    System.out.println(customer.name + " ordered " + quantity + " of " + product.getName());
                    
                    // Check for low stock
                    if (product.getQuantity() < lowStockThreshold) {
                        System.out.println("Alert: Low stock for product " + product.getName() + " (ID: " + product.getId() + "). Only " + product.getQuantity() + " left.");
                    }
                } else {
                    System.out.println("Sorry, only " + product.getQuantity() + " items available in stock.");
                }
                return;
            }
        }
        System.out.println("Product not found.");
    }

    // Generate statistics
    public void generateStatistics() {
        int totalGoods = 0;
        int totalCargo = 0;

        for (Product product : products) {
            if (product.getType().equals("good")) {
                totalGoods += product.getQuantity();
            } else if (product.getType().equals("cargo")) {
                totalCargo += product.getQuantity();
            }
        }

        System.out.println("Statistics: ");
        System.out.println("Total Goods: " + totalGoods);
        System.out.println("Total Cargo: " + totalCargo);
    }

    // Getter for GUI or other use cases
    public List<Product> getProducts() {
        return products;
    }
}
